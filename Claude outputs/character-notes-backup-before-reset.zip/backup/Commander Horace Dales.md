---
name: Commander Horace Dales
role: supporting
age: "58"
employer: Icarus Group
ship: Icarus
type: character
---
# Commander Horace Dales

## Physical Description
_None provided._

## Personality
_None provided._

## Goals
_None provided._

## Secrets
_None provided._