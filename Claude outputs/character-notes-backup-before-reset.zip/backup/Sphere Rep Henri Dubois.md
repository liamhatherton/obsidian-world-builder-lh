---
name: Sphere Rep Henri Dubois
role: antagonist
age: "37"
employer: Sphere
ship: "Icarus"
type: character
---
# Sphere Rep Henri Dubois

## Physical Description
_None provided._

## Personality
_None provided._

## Goals
_None provided._

## Secrets
_None provided._