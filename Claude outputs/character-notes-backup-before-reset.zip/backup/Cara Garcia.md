---
name: Cara Garcia
role: protagonist
age: "23"
employer: Icarus Group
ship: Icarus
type: character
home: Dominican Republic
---
# Cara Garcia
![[Cara3.jpg|316]]

**Origin/Home:**
grew up on [[Colonia]]

(past) was born on the Dominican Archipelago (was previously the Dominican Republic before being annexed by the USA, and then annexed by the 2nd Republic of Texas, and then annexed by the [[Northern Hemisphere Authority]] / NHA
		
**Role in Story:**
A new recruit and love interest of [[Desmond Hughes|Desmond]]

**Goal:**
To find a career path that suits her.  She briefly worked as a cook before joining the Icarus crew, leading to many of the crew joking with her to grab her a coffee.

**Physical Description:**
A slender woman of dominican heritage with curly black hair usually dyed with blonde or blue highlights.

**Personality:**
Isn’t shy but is very meek in her form of being quiet around others. Also has a sense of humor and isn’t afraid of trading friendly barbs.  Can become very abrasive on the drop of a hat if she feels someone is threatening her or her fellow crew. But generally cute and happy and finds it suitable to just go with the flow for whatever task is at hand.  Has a crush on [[Desmond Hughes|Desmond]].

**Occupation:**
Chemical specialist and ore/material identification for mineral extraction.  Also a welder, aiding in custom drone fits.

**Habits/Mannerisms:**
Quiet, meek, quick to flash a smile.  Flirty.

**Background:**
Has family on [[Colonia]].  Grew up very poor, but not uncomfortably so.  Mother was a cook and sister was an artist.

**Internal Conflicts:**
Is unsure of herself, despite having naturally good instincts in any given situation.  Is slow to suggest ideas at first until comfortable with her group.

Has a crush on [[Desmond Hughes|Desmond]], with both going out of their way to make it a point of only being professional to each other.

**External Conflicts:**
Since English is not her first language, she struggles sometimes interacting with the crew.  She practices english with [[Desmond Hughes|Desmond]] on their downtime sometimes.