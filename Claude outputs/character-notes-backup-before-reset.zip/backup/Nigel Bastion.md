---
name: Nigel Bastion
role: protagonist
age: "23"
employer: Icarus Group
ship: Icarus
type: character
home: Brighton, England
---
# Nigel Bastion
![[nigel bastion.png|287]]

## Physical Description
_None provided._

## Personality
_None provided._

## Goals
_None provided._

## Secrets
_None provided._