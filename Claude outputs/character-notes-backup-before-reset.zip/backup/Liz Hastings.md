---
name: Liz Hastings
role: protagonist
age: "30"
employer: Icarus Group
ship: Icarus
type: character
home: Denver, Colorado
---
# Liz Hastings
![[Gemini_Generated_Image_s38js2s38js2s38j - Copy.png|335]]

## Physical Description
_None provided._

## Personality
_None provided._

## Goals
_None provided._

## Secrets
_None provided._