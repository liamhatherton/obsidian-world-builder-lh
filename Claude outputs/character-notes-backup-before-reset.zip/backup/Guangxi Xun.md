---
name: Guangxi Xun
role: protagonist
age: "19"
employer: Icarus Group
ship: Icarus
type: character
home: Shenzhen, China
---
# Guangxi Xun
![[guangxi.png]]

## Physical Description
_None provided._

## Personality
_None provided._

## Goals
_None provided._

## Secrets
_None provided._