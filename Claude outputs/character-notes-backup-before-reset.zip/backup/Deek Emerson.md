---
name: Deek Emerson
role: protagonist
age: "39"
employer: Icarus Group
ship: Icarus
type: character
home: Newark, New Jersey
---
# Deek Emerson
![[deek emerson - Copy.png]]

## Physical Description
_None provided._

## Personality
_None provided._

## Goals
_None provided._

## Secrets
_None provided._