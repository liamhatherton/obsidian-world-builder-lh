---
name: Emi Li
role: protagonist
age: "28"
employer: Icarus Group
ship: Icarus
type: character
home: Hsinchu, China
---
# Emi Li
![[emi li - Copy.png|272]]

## Physical Description
_None provided._

## Personality
_None provided._

## Goals
_None provided._

## Secrets
_None provided._