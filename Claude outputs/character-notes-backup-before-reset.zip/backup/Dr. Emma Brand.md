---
name: Dr. Emma Brand
role: supporting
age: "34"
employer: Icarus Group
ship: Icarus
type: character
---
# Dr. Emma Brand

## Physical Description
_None provided._

## Personality
_None provided._

## Goals
_None provided._

## Secrets
_None provided._