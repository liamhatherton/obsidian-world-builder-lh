---
name: Thomas Alps
role: protagonist
age: "30"
employer: Icarus Group
ship: Icarus
type: character
home: New York City
---
# Thomas Alps
![[thomas alps - Copy 1.png]]

## Physical Description
_None provided._

## Personality
_None provided._

## Goals
_None provided._

## Secrets
_None provided._