---
name: Captain Roland McQueen
role: supporting
age: "49"
employer: Icarus Group
ship: Icarus
type: character
---
# Captain Roland McQueen

## Physical Description
_None provided._

## Personality
_None provided._

## Goals
_None provided._

## Secrets
_None provided._