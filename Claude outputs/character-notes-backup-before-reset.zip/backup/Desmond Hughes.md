---
name: Desmond Hughes
role: protagonist
age: "36"
employer: Icarus Group
ship: Icarus
type: character
home: Colonia
---
# Desmond Hughes
![[desmond - Copy.jpg]]

## <font color="#fac08f">Origin</font>
[[Colonia]]

## Physical Description
White. Medium build, slightly pudgy belly on account of poor diet.  Dark blonde hair.  Permanent five o clock shadow facial hair. 

**Origin/Home:**
born and grew up on [[Colonia]]

Parents from [[Northern Hemisphere Authority]] (was previously Colorado, USA and then annexed by the Northern Hemisphere Authority)

**Resume:**
(current) Crew Manager Class 3 de Icarus / [[Icarus Group]] [[Sphere]] franchisee
(past) Reserve Military Training Outfit / RMTO graduate

**Role in Story:**
Main character.  First member of his team, often in a leadership position and having a call on final decisions.  

**Goal:**
Seeking a place where he can be himself without any expectations.  

**Personality:**
Has symptoms of ADHD he struggles with and can be hot or cold with others.  Usually he finds himself caring very much about the input of others in his friend group, but he is usually questioning everyone else and their motives.  

When under pressure, Desmond is very goal oriented and seeks optimization and balance which makes him appear distant to others, albeit in a thoughtful way.

To others, Desmond can seem a little aimless at times, but he is internally enjoying freedom from expectations.

**Occupation:**
Crew Manager Class 3 - Reports to ship command and manages the performance of his group and is accountable for their resource usage and equipment acquisition.

While in school on [[Earth]] as a child, he joined the [[Reserve Military Training Outfit]] (RMTO), a recruiting arm of the Earth Military Forces (EMF) designed to identify potential combat, operations, and command youth and provide a career path.  Desmond only joined as a rebellion against his parents who were in station construction careers.  

**Habits/Mannerisms:**
Loves real milk, but can rarely find it off [[Earth]] or [[Las Luna]].  Often goes with little sleep, making him somewhat cranky after waking.  However, underneath a protected exterior, Desmond is quite empathetic. Theoretically 

**Background:**
His parents died in a space elevator accident leaving him with 1 brother (Chuck) and an inheritance that he never asked for and has not spent.  He wanted to find meaning in his life, a place where he could be good at something and answered one of the many ubiqituous advertisements for [[Sphere]].  Starting as a greenhorn, his first captain saw potential management material as the others listened to him and respected him.  

**Internal Conflicts:**
Has trouble managing time, often putting 110% of himself into something when demanded, and then also having trouble to maintain interest in anything he found nothing interesting about.

While in RMTO as a youth, Desmond shot and killed a thief on [[Colonia]] where he was temporarily stationed, a thief who was stealing electrical equipment after sneaking onto Colonia from an unlicensed frigate.  The thief was part of a brutal gang, but killing a man has brought much turmoil in Desmond’s life.

**External Conflicts:**
Has had an on/off again affair with Liz who has been dating Nigel for a few months.  

Really dislikes the science team because they never seem to care about employee safety.  Especially distrustful of Dr. Boris Sokolov because he seems to treat the crew as animals he is viewing from a cage.  