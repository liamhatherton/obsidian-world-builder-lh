---
name: Dr. Boris Sokolov
role: antagonist
age: "42"
employer: Icarus Group
ship: Icarus
type: character
---
# Dr. Boris Sokolov

## Physical Description
_None provided._

## Personality
_None provided._

## Goals
_None provided._

## Secrets
_None provided._